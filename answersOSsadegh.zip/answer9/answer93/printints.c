#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	FILE* ptr;
	char ch;

	ptr = fopen("/proc/interrupts", "r");

	if (NULL == ptr) {
		printf("file can't be opened \n");
	}

	printf("interrupts are: \n");

	do {
		ch = fgetc(ptr);
		printf("%c", ch);
	} while (ch != EOF);

	// Closing the file
	fclose(ptr);
	return 0;
}

