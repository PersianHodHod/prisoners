#include <linux/kallsyms.h>
#include <linux/module.h>
#include <linux/init.h>

MODULE_AUTHOR("Sadegh and Abolfazl");
MODULE_LICENSE("GPL");

int i;

unsigned long long int* manjaro_sys_table;

static int __init before_module(void){
    printk("before module is running... \n");
    manjaro_sys_table = (unsigned long long int*) kallsyms_lookup_name("sys_call_table");
    
    // read __NR_syscalls:436 from usr/include/asm-generic/unistd.h
    for (i = 0; i < 436; i++) {
        printk("%d syscall address of manjaro is: %p \n", i, (void*)manjaro_sys_table[i]);
    }

    return 0;
}

static void __exit after_module(void){
    printk("after module is running... \n");
}

module_init(before_module);
module_exit(after_module);
