#include <linux/module.h>
#include <linux/init.h>
#include <linux/kallsyms.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Sadegh and Abolfazl");

unsigned long long int* manjaro_sys_table;
void (*open_syscall_pointer)(void);


// helper reference: https://gist.github.com/CaledoniaProject/d48f5d65d9a334f702a485a0391b271e
// https://github.com/xcellerator/linux_kernel_hacking/issues/3
inline void mywrite_cr0(unsigned long cr0) {
    asm volatile("mov %0,%%cr0" : "+r"(cr0), "+m"(__force_order));
}

void enable_w_protection(void) {
    unsigned long cr0 = read_cr0();
    set_bit(16, &cr0);
    mywrite_cr0(cr0);
}

void disable_w_protection(void) {
    unsigned long cr0 = read_cr0();
    clear_bit(16, &cr0); mywrite_cr0(cr0);
}

void instead_function(void){
    printk("my instead function is running...\n");
    // todo: change address:
    open_syscall_pointer = (void (*)(void))0x12345678;
    (*open_syscall_pointer)();
}

static int __init before_module(void){
    printk("before module is running... \n");

    manjaro_sys_table = (unsigned long*) kallsyms_lookup_name("sys_call_table");

    disable_w_protection();
    manjaro_sys_table[2] = (unsigned long) instead_function;
    enable_w_protection();    
    return 0;
}

static void __exit after_module(void){
    printk("after module is running... \n");
}

module_init(before_module);
module_exit(after_module);
